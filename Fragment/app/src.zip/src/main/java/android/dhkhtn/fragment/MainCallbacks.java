package android.dhkhtn.fragment;

/**
 * Created by DELL on 3/30/2018.
 */

public interface MainCallbacks {

       public  void onMsgFromFragToMain(String sender, String strValue);

}
