package android.dhkhtn.listview;

/**
 * Created by DELL on 3/20/2018.
 */

public class Text {
    String name;

    public Text(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {

        return name;
    }
}
