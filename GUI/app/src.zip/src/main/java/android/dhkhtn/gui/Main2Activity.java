package android.dhkhtn.gui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {

    String NAME="name";
    String PASSWORD ="PASSWORD";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText txtName = (EditText) findViewById(R.id.txtName);
        EditText txtPassword = (EditText) findViewById(R.id.txtPassword);

        Intent intent = getIntent();
        String name = intent.getStringExtra(NAME);
        txtName.setText(name);


    }
}
