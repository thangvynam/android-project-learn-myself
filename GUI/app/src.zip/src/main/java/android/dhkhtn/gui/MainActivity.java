package android.dhkhtn.gui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    EditText txtName,txtPassword,txtRetype,txtDate;
    Button btnSelect,btnReset,btnSignUp;
    RadioButton radMale,radFemale;
    String NAME="name";
    String PASSWORD="PASSWORD";
    CheckBox chkTennis,chkFutbal,chkOther;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtName = (EditText) findViewById(R.id.txtName);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
        txtRetype = (EditText) findViewById(R.id.txtRetype);
        txtDate = (EditText) findViewById(R.id.txtDate);
        btnSelect = (Button) findViewById(R.id.btnSelect);
        radMale = (RadioButton) findViewById(R.id.radMale);
        radFemale = (RadioButton) findViewById(R.id.radFemale);
        chkTennis = (CheckBox) findViewById(R.id.chkTennis);
        chkFutbal = (CheckBox) findViewById(R.id.chkFutbal);
        chkOther = (CheckBox) findViewById(R.id.chkOther);
        btnReset = (Button) findViewById(R.id.btnReset);
        btnSignUp = (Button) findViewById(R.id.btnSignUp);
        radFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(radMale.isChecked()){
                    radMale.setChecked(false);
                }
            }
        });
        radMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(radFemale.isChecked()){
                    radFemale.setChecked(false);
                }
            }
        });


        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtName.setText("");
                txtPassword.setText("");
                txtRetype.setText("");
                txtDate.setText("");
                radFemale.setChecked(false);
                radMale.setChecked(false);
                chkFutbal.setChecked(false);
                chkTennis.setChecked(false);
                chkOther.setChecked(false);
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                intent.putExtra(NAME,txtName.getText().toString());
                intent.putExtra(PASSWORD,txtPassword.getText().toString());
                startActivity(intent);

            }
        });
    }


}
